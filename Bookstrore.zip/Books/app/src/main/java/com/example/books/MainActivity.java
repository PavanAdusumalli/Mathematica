package com.example.books;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Book> title = new ArrayList<>();
//    ArrayList<String> publisher=new ArrayList<>();
//    ArrayList<String> year=new ArrayList<>();

    ArrayList ArrList2 = (ArrayList) title.clone();

    String[] item_lst;
    ListView listView;
    BookAdapter bookAdapter;
    private static final String FILE_NAME = "Output.txt";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list_item);
        registerForContextMenu(listView);


        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                PackageManager.PERMISSION_GRANTED);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.resource_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.Load)
        {
            String data = "";
            data = "Python Development,AnnaBella Corporation,Anny,2001,/sdcard/Download/python.jpeg;Java Development,AnnaBella Corporation,Anny,2001,/sdcard/Download/java.jpg;Android Development,AnnaBella Corporation,Anny,2001,/sdcard/Download/android.jpg";
            item_lst = data.split(";");
            for (String i : item_lst) {
                String[] object = i.split(",");
                Bitmap bmp = BitmapFactory.decodeFile(object[4]);
//                publisher.add(object[1]);
//                year.add(object[3]);
                title.add(new Book(bmp, object[0], object[1], object[2], object[3], object[4]));
                BookAdapter bookAdapter = new BookAdapter(MainActivity.this, R.layout.list_row, title);
                listView.setAdapter(bookAdapter);
            }
        }
        else if (item.getItemId() == R.id.Delete) {
            bookAdapter.clear();
            bookAdapter.notifyDataSetChanged();

        } else if (item.getItemId() == R.id.Save) {
            String str_save = "";
            for (int i = 0; i < title.size(); i++) {
                str_save = str_save + new StringBuilder(String.valueOf(title.get(i).name)) + "," + new StringBuilder(String.valueOf(title.get(i).publisher)) + "," + new StringBuilder(String.valueOf(title.get(i).author)) + "," + new StringBuilder(String.valueOf(title.get(i).year)) + "," + new StringBuilder(String.valueOf(title.get(i).path) + ";");
            }save(str_save);

        } else {
            return false;
        }
        return true;
    }

    private void save(String str_save)
    {
        String text = str_save;
        FileOutputStream fos = null;

        try
        {
            fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
            fos.write(text.getBytes());
            Toast.makeText(this, "Books Saved Successfully!!", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        } finally
        {
            if (fos != null)
            {
                try
                {
                    fos.close();
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }



    public void btn_showDialog(View view) {

        AlertDialog.Builder alert=new AlertDialog.Builder(MainActivity.this);
        View mview=getLayoutInflater().inflate(R.layout.dialog_box,null);

        EditText txt1=(EditText)mview.findViewById(R.id.editText1);
        EditText txt2=(EditText)mview.findViewById(R.id.editText2);
        EditText txt3=(EditText)mview.findViewById(R.id.editText3);
        EditText txt4=(EditText)mview.findViewById(R.id.editText4);
        EditText txt5=(EditText)mview.findViewById(R.id.editText5);
        Button ok_btn=(Button)mview.findViewById(R.id.ok_button);
        Button cancel_btn=(Button)mview.findViewById(R.id.cancel_button);

        alert.setView(mview);

        final AlertDialog alertDialog=alert.create();
        alertDialog.setCanceledOnTouchOutside(false);

        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });



        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String item1="",item2="",item3="",item4="",item5="";
                if(txt1.getText().toString().equals("") || txt2.getText().toString().equals("") || txt3.getText().toString().equals("") || txt4.getText().toString().equals(""))
                {
                    Toast.makeText(MainActivity.this, "Please fill the entries!!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    item1=txt1.getText().toString();
                    item2=txt2.getText().toString();
                    item3=txt3.getText().toString();
                    item4=txt4.getText().toString();
                    item5=txt5.getText().toString();

//                    publisher.add(item2);
//                    year.add(item4);
                    try {
                        String path="/sdcard/Download/"+item5;
                        Bitmap bmp= BitmapFactory.decodeFile(path);
                        title.add(new Book(bmp,item1,item2,item3,item4,item5));
                        Toast.makeText(MainActivity.this, "Book added Successfully", Toast.LENGTH_SHORT).show();
                    }catch (Exception e)
                    {
                        Toast.makeText(MainActivity.this, "Image Not Found!!", Toast.LENGTH_SHORT).show();
                    }

                    //adapter
                    bookAdapter=new BookAdapter(MainActivity.this,R.layout.list_row,title);
                    listView.setAdapter(bookAdapter);
                    alertDialog.dismiss();
                }
            }
        });
        alertDialog.show();


    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.book_list,menu);
        menu.setHeaderTitle("Select Action");

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.edit)
        {
           dialog();
        }
        else if(item.getItemId()==R.id.delete)
        {
            bookAdapter.clear();
            bookAdapter.notifyDataSetChanged();
        }
        else
        {
            return false;
        }
        return true;
    }

    private void dialog() {
        AlertDialog.Builder alert=new AlertDialog.Builder(MainActivity.this);
        View mview=getLayoutInflater().inflate(R.layout.dialog_box,null);

        EditText txt1=(EditText)mview.findViewById(R.id.editText1);
        EditText txt2=(EditText)mview.findViewById(R.id.editText2);
        EditText txt3=(EditText)mview.findViewById(R.id.editText3);
        EditText txt4=(EditText)mview.findViewById(R.id.editText4);
        EditText txt5=(EditText)mview.findViewById(R.id.editText5);
        Button ok_btn=(Button)mview.findViewById(R.id.ok_button);
        Button cancel_btn=(Button)mview.findViewById(R.id.cancel_button);

        alert.setView(mview);

        final AlertDialog alertDialog=alert.create();
        alertDialog.setCanceledOnTouchOutside(false);

        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });



        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String item1="",item2="",item3="",item4="",item5="";
                if(txt1.getText().toString().equals("") || txt2.getText().toString().equals("") || txt3.getText().toString().equals("") || txt4.getText().toString().equals(""))
                {
                    Toast.makeText(MainActivity.this, "Please fill the entries!!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    item1=txt1.getText().toString();
                    item2=txt2.getText().toString();
                    item3=txt3.getText().toString();
                    item4=txt4.getText().toString();
                    item5=txt5.getText().toString();

//
//                    publisher.add(item2);
//                    year.add(item4);
                    try {
                        String path="/sdcard/Download/"+item5;
                        Bitmap bmp= BitmapFactory.decodeFile(path);

                        title.add(new Book(bmp, item1,item2,item3,item4,item5));
                        Toast.makeText(MainActivity.this, "Book added Successfully", Toast.LENGTH_SHORT).show();
                    }catch (Exception e)
                    {
                        Toast.makeText(MainActivity.this, "Image Not Found!!", Toast.LENGTH_SHORT).show();
                    }

                    //adapter
                    BookAdapter bookAdapter=new BookAdapter(MainActivity.this,R.layout.list_row,title);
                    listView.setAdapter(bookAdapter);

                    alertDialog.dismiss();
                }
            }
        });
        alertDialog.show();
    }

}