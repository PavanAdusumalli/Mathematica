package com.example.books;

import android.graphics.Bitmap;

public class Book
{

    Bitmap image;
    String name;
    String publisher;
    String author;
    String year;
    String path;

    public Book(Bitmap image, String name, String pub, String dis,String year,String path) {
        this.image = image;
        this.name = name;
        this.publisher=pub;
        this.author = dis;
        this.year=year;
        this.path=path;

    }

    public String Add()
    {
        String str="";
        str=str+name+publisher+author+author+year;
        return str;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDis() {
        return author;
    }

    public void setDis(String dis) {
        this.author = dis;
    }
}
