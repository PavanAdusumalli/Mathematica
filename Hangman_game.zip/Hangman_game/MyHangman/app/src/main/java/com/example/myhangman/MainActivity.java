package com.example.myhangman;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String PREF_WINS = "wins";
    private static final String PREF_LOSSES = "losses";

    private HangmanGame hangmanGame;
    private EditText guessInput;
    private ImageView hangmanImage;
    private TextView winsTextView;
    private TextView lossesTextView;
    private TextView partiallyGuessedTextView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getPreferences(Context.MODE_PRIVATE);

        hangmanGame = new HangmanGame(this);

        guessInput = findViewById(R.id.editTextGuess);
        hangmanImage = findViewById(R.id.imageViewHangman);
        winsTextView = findViewById(R.id.textViewWins);
        lossesTextView = findViewById(R.id.textViewLosses);
        partiallyGuessedTextView = findViewById(R.id.textViewPartiallyGuessed);

        updateUI();

        Button guessButton = findViewById(R.id.buttonGuess);
        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onGuessButtonClick();
            }
        });

        ListView difficultyListView = findViewById(R.id.listViewDifficulty);
        String[] difficultyLevels = {"Easy", "Medium", "Hard"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, difficultyLevels);
        difficultyListView.setAdapter(adapter);

        difficultyListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                onDifficultySelected(position);
            }
        });

        Button menuButton = findViewById(R.id.buttonMenu);
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(view);
            }
        });
    }

    private void onGuessButtonClick() {
        String guess = guessInput.getText().toString().toLowerCase();

        if (guess.length() == 1 && Character.isLetter(guess.charAt(0))) {

            hangmanGame.makeGuess(guess.charAt(0));

            if (hangmanGame.isCorrectLastGuess()) {
                showToast("Correct guess! Keep going!");
            } else {
                showToast("Incorrect guess. Try again.");
            }
        } else {

            showToast("Invalid input. Please enter a single letter.");
        }

        updateUI();
    }

    private void onDifficultySelected(int difficulty) {
        String[] difficultyLevels = {"Easy", "Medium", "Hard"};
        String selectedDifficulty = difficultyLevels[difficulty];

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Difficulty Selected");
        builder.setMessage("You have chosen the " + selectedDifficulty + " level.");

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                hangmanGame.setDifficulty(difficulty);
                hangmanGame.startNewGame();
                updateUI();
            }
        });

        builder.show();
    }

    private void updateUI() {
        hangmanImage.setImageResource(hangmanGame.getHangmanImageResource());
        winsTextView.setText("Wins: " + hangmanGame.getWins());
        lossesTextView.setText("Losses: " + hangmanGame.getLosses());

        String partiallyGuessedWord = hangmanGame.getPartiallyGuessedWord();
        partiallyGuessedTextView.setText(partiallyGuessedWord);

        if (hangmanGame.isGameOver()) {
            showGameOverDialog();
        }
    }

    private void showGameOverDialog() {
        String message;
        if (hangmanGame.isGameWon()) {
            message = "Congratulations! You guessed the word!";
        } else {
            message = "Sorry, you lost. The word was: " + hangmanGame.getSecretWord();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Game Over");
        builder.setMessage(message);


        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                hangmanGame.startNewGame();
                updateUI();
            }
        });

        builder.show();
    }

    private void showPopupMenu(View view) {
        if (view != null) {
            PopupMenu popupMenu = new PopupMenu(this, view);
            popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(android.view.MenuItem menuItem) {
                    int itemId = menuItem.getItemId();

                    if (itemId == R.id.menuWinsLosses) {
                        showWinsLossesDialog();
                        return true;
                    } else if (itemId == R.id.menuReset) {
                        resetWinsLosses();
                        return true;
                    } else if (itemId == R.id.menuNewGame) {
                        hangmanGame.startNewGame();
                        updateUI();
                        return true;
                    } else {
                        return false;
                    }
                }
            });

            popupMenu.show();
        }
    }

    private void showWinsLossesDialog() {

    }

    private void resetWinsLosses() {
        hangmanGame.resetWinsLosses();
        updateUI();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
