package com.example.myhangman;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HangmanGame {
    private static final String PREF_WINS = "wins";
    private static final String PREF_LOSSES = "losses";

    private static final String[] EASY_WORDS = {"Dog", "Cat", "Sun", "Hat", "Red", "Cup", "Bed"};
    private static final String[] MEDIUM_WORDS = {"Mountain", "Guitar", "Rainbow", "Camera", "Laptop", "Garden", "Diamond"};
    private static final String[] HARD_WORDS = {"Onomatopoeia", "Serendipity", "Cryptocurrency", "Paradox", "Exponential"};

    private static final int MAX_EASY_GUESSES = 6;
    private static final int MAX_MEDIUM_GUESSES = 5;
    private static final int MAX_HARD_GUESSES = 4;
    private final StringBuilder partiallyGuessedWord;

    private String secretWord; // stores the current secret word for the game
    private List<Character> guessedLetters; //Keeps track of the letters guessed by the user
    private int incorrectGuesses;// count of incorrect guesses.
    private int wins;
    private int losses;
    private int difficulty;
    private boolean lastGuessCorrect;

    public HangmanGame(Context context) {
        guessedLetters = new ArrayList<>(); // empty list to store the guessed letters
        difficulty = 0; //choosing easy level by default

        //Retrieves shared preferences named "HangmanPrefs" specific to this game.
        // These preferences are used to store and retrieve game data like wins and losses.
        SharedPreferences sharedPreferences = context.getSharedPreferences("HangmanPrefs", Context.MODE_PRIVATE);

        // Retrieves the no of wins and losses from sharedPref
        wins = sharedPreferences.getInt(PREF_WINS, 0);
        losses = sharedPreferences.getInt(PREF_LOSSES, 0);

        partiallyGuessedWord = new StringBuilder();
        // Calling the selectRandomWord() method to choose a random word from a word list
        // based on difficulty level.
        selectRandomWord();

        // Calling the updatePartiallyGuessedWord method to initialize the partially guessed word
        // based on the chosen random word
        updatePartiallyGuessedWord();
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public String getSecretWord() {
        return secretWord;
    }

    public String getPartiallyGuessedWord() {
        return partiallyGuessedWord.toString();
    }

    public void startNewGame() {
        guessedLetters.clear();
        incorrectGuesses = 0;
        selectRandomWord();
        updatePartiallyGuessedWord();
    }

    public void updatePartiallyGuessedWord() {
        partiallyGuessedWord.setLength(0);
        boolean letterGuessed = false; // Track if the letter was found in any word

        for (int i = 0; i < secretWord.length(); i++) {
            char letter = secretWord.charAt(i);
            if (guessedLetters.contains(letter)) {
                partiallyGuessedWord.append(letter);
                letterGuessed = true; // Flag that the letter was found
            } else {
                partiallyGuessedWord.append('_');
            }
        }

        // If the guessed letter was not found in any word, update partiallyGuessedWord for all words
        if (!letterGuessed) {
            for (String word : EASY_WORDS) {
                for (int i = 0; i < word.length(); i++) {
                    char letter = word.charAt(i);
                    if (guessedLetters.contains(letter)) {
                        partiallyGuessedWord.setCharAt(i, letter);
                    }
                }
            }
        }
    }


    private void selectRandomWord() {
        String[] wordList;

        if (difficulty == 0) {
            wordList = EASY_WORDS;
        } else if (difficulty == 1) {
            wordList = MEDIUM_WORDS;
        } else if (difficulty == 2) {
            wordList = HARD_WORDS;
        } else {
            throw new IllegalArgumentException("Invalid difficulty level");
        }

        Random random = new Random();
        secretWord = wordList[random.nextInt(wordList.length)];

        if (secretWord == null) {
            throw new IllegalStateException("Selected word is null");
        }

        secretWord = secretWord.toLowerCase();
    }

    public void makeGuess(char letter) {
        letter = Character.toLowerCase(letter);

        if (secretWord != null && !isGameLost()) {
            if (!guessedLetters.contains(letter)) {
                guessedLetters.add(letter);

                if (secretWord.indexOf(letter) == -1) {

                    incorrectGuesses++;
                } else {

                    lastGuessCorrect = true;
                }
            } else {

                lastGuessCorrect = false;
            }

            Log.d("HangmanGame", "Last guess: " + letter);
            Log.d("HangmanGame", "Is last guess correct? " + lastGuessCorrect);
            Log.d("HangmanGame", "Incorrect guesses: " + incorrectGuesses);
            Log.d("HangmanGame", "Max guesses: " + getMaxGuesses());


            if (isGameWon()) {
                wins++;

            }

            if (isGameLost()) {
                losses++;

            }

            updatePartiallyGuessedWord();
        }
    }

    public boolean isCorrectLastGuess() {
        char lastGuess = guessedLetters.isEmpty() ? '\0' : guessedLetters.get(guessedLetters.size() - 1);

        if (secretWord != null) {
            return secretWord.indexOf(lastGuess) != -1;
        } else {
            return false;
        }
    }

    public boolean isGameOver() {
        return isGameWon() || isGameLost();
    }

    public boolean isGameWon() {
        if (secretWord == null) {
            return false;
        }

        for (char letter : secretWord.toCharArray()) {
            if (!guessedLetters.contains(letter)) {
                return false;
            }
        }
        return true;
    }

    public boolean isGameLost() {
        int maxGuesses = getMaxGuesses();
        return incorrectGuesses >= maxGuesses;
    }

    public int getHangmanImageResource() {
        if (isGameLost()) {

            return R.drawable.image7;
        } else {

            int maxGuesses = getMaxGuesses();
            int imageNumber = Math.min(incorrectGuesses, maxGuesses);

            if (imageNumber == 0) {
                return R.drawable.image1;
            } else if (imageNumber == 1) {
                return R.drawable.image2;
            } else if (imageNumber == 2) {
                return R.drawable.image3;
            } else if (imageNumber == 3) {
                return R.drawable.image4;
            } else if (imageNumber == 4) {
                return R.drawable.image5;
            } else if (imageNumber == 5) {
                return R.drawable.image6;
            } else if (imageNumber == 6) {
                return R.drawable.image7;
            } else {
                throw new IllegalArgumentException("Invalid hangman image number");
            }
        }
    }

    private int getMaxGuesses() {
        switch (difficulty) {
            case 0:
                return MAX_EASY_GUESSES;
            case 1:
                return MAX_MEDIUM_GUESSES;
            case 2:
                return MAX_HARD_GUESSES;
            default:
                throw new IllegalArgumentException("Invalid difficulty level");
        }
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public void resetWinsLosses() {
        wins = 0;
        losses = 0;
    }

    public boolean isLastGuessCorrect() {
        return lastGuessCorrect;
    }
}
